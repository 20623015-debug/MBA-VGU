# GF-FJSP-PM Metaheuristics

## Thesis Implementation

**Enhanced Metaheuristics for Green Fuzzy Processing Time Flexible Job Shop Scheduling with Preventive Maintenance**

## Objective Function (Thesis Eq. 3.15)

```
Total Cost = C_time + C_energy + C_PM + C_startup
```

Where:
- **C_time** = c_time × Cmax ($100/hour × hours)
- **C_energy** = c_energy × E ($0.08/kWh × kWh)  
- **C_PM** = c_pm_direct + c_pm_delay × delay
- **C_startup** = c_startup × machines_used

## Algorithms Implemented

| Algorithm | Description | Reference |
|-----------|-------------|-----------|
| **ADP-ACO** | Adaptive Dual-Pheromone ACO | Proposed (Chapter 4) |
| **HGATS** | Hybrid GA with Tabu Search | Li & Gao (2016) |
| **HGAVND** | Hybrid GA with VND | Gao et al. (2008) |

## Project Structure

```
GF_FJSP_PM/
├── Program.cs           # Complete implementation (2086 lines)
├── GF_FJSP_PM.csproj    # .NET 8.0 project file
├── README.md            # This file
└── instances/           # Benchmark instances
    ├── GF-LA01.json
    ├── GF-LA03.json
    ├── GF-LA04.json
    ├── GF-LA06.json
    └── GF-LA11.json
```

## Building and Running

### Prerequisites
- .NET 8.0 SDK or later

### Build
```bash
dotnet build --configuration Release
```

### Run
```bash
# Default: current directory, 10 runs, 100 iterations
dotnet run

# Custom parameters
dotnet run -- -d ./instances -r 10 -i 100

# Show help
dotnet run -- --help
```

### Command Line Options

| Option | Description | Default |
|--------|-------------|---------|
| `-d, --dir <path>` | Instance directory | Current dir |
| `-r, --runs <n>` | Number of runs | 10 |
| `-i, --iter <n>` | Max iterations | 100 |
| `-h, --help` | Show help | - |

## Output Files

- **comparison_results.json**: Detailed results for all algorithms
- **convergence_data.json**: Convergence curves for plotting

## Key Features

### ADP-ACO (Proposed Algorithm)
- Dual pheromone trails: operation sequence (τ_op) + machine selection (τ_mach)
- Attractive (τ⁺) and Repulsive (τ⁻) pheromones
- Adaptive q₀: exploration → exploitation
- Stagnation detection with restart mechanism
- Multi-neighborhood local search

### Parameters (Thesis Table 4.1)

| Parameter | Value | Reference |
|-----------|-------|-----------|
| NumAnts | 30 | Dorigo & Stützle (2004) |
| α (pheromone) | 1.0 | Dorigo & Gambardella (1997) |
| β (heuristic) | 2.0 | Dorigo & Gambardella (1997) |
| γ (repulsive) | 0.5 | Novel contribution |
| ρ⁺ (evaporation) | 0.1 | Stützle & Hoos (2000) |
| ρ⁻ (evaporation) | 0.3 | Novel contribution |
| Stagnation | 15 | Stützle & Hoos (2000) |

## Fixes Applied (vs. Original)

1. **PM Cost Calculation**: Fixed to schedule PM optimally within window
2. **Energy Calculation**: Fixed idle time to only count for used machines
3. **Redundant Decode()**: Cached results to avoid multiple calls
4. **HGAVND**: Completed missing Solve() method body
5. **PrintDetails**: Added missing flag property
6. **Main()**: Added proper entry point with CLI argument parsing

## Statistical Analysis

The code includes:
- **Wilcoxon Signed-Rank Test**: Pairwise comparison (α=0.05)
- **Friedman Test**: Overall algorithm ranking

## Sample Output

```
====================================================================================================
GF-FJSP-PM ALGORITHM COMPARISON
Cost-Based Objective (Thesis Eq. 3.15)
====================================================================================================

Instance: GF-LA01 (10×5, 50 ops, BKS=666)
----------------------------------------------------------------------------------------------------
Algorithm    Best($)      Avg($)       Std        Time(s)    RPD(%)     Rank  
----------------------------------------------------------------------------------------------------
ADP-ACO      111234.56    111456.78    123.45     12.34      0.00       1     
HGATS        111567.89    111789.01    156.78     8.56       0.30       2     
HGAVND       111890.12    112012.34    189.01     6.78       0.59       3     
```

## License

Academic use for thesis research.

## Author

Hoang Hai Trieu  
Vietnamese-German University / Heilbronn University  
Master's Thesis, 2025
