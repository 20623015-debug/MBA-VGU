/*
 * ============================================================================
 * GF-FJSP-PM METAHEURISTICS - COST-BASED OBJECTIVE
 * ============================================================================
 * 
 * THESIS: Enhanced Metaheuristics for Green Fuzzy Processing Time Flexible 
 *         Job Shop Scheduling with Preventive Maintenance
 * 
 * OBJECTIVE FUNCTION (Thesis Eq. 3.15):
 *   Total Cost = C_time + C_energy + C_PM + C_startup
 *   Where:
 *     C_time    = c_time × Cmax           ($100/hour × hours)
 *     C_energy  = c_energy × E            ($0.08/kWh × kWh)
 *     C_PM      = c_pm_direct + c_pm_delay × delay
 *     C_startup = c_startup × machines_used
 * 
 * BENCHMARKS:
 *   - GF-LA01, GF-LA03, GF-LA04, GF-LA06, GF-LA11 (Lawrence JSP)
 * 
 * ALGORITHMS:
 *   - ADP-ACO: Adaptive Dual-Pheromone ACO (Proposed, Chapter 4)
 *   - HGATS:   Hybrid GA with Tabu Search (Li & Gao, 2016)
 *   - HGAVND:  Hybrid GA with VND (Gao et al., 2008)
 * 
 * FIXES APPLIED:
 *   - PM cost calculation corrected
 *   - Energy idle time calculation fixed
 *   - Redundant Decode() calls optimized
 *   - HGAVND Solve() completed
 *   - PrintDetails flag added
 * 
 * ============================================================================
 */

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Diagnostics;

namespace GF_FJSP_PM_Thesis
{
    #region Data Structures
    
    /// <summary>
    /// Triangular Fuzzy Number (TFN)
    /// Thesis Section 3.3: p̃ = (pL, pM, pU)
    /// </summary>
    public class TFN
    {
        public double L { get; set; }
        public double M { get; set; }
        public double U { get; set; }
        
        /// <summary>
        /// GMIR Defuzzification (Thesis Eq. 3.2)
        /// p̂ = (L + 4*M + U) / 6
        /// </summary>
        public double GMIR => (L + 4.0 * M + U) / 6.0;
    }
    
    /// <summary>
    /// Operation with FJSP flexibility
    /// Each operation can be processed on multiple machines
    /// </summary>
    public class Operation
    {
        public int JobId { get; set; }
        public int OpIdx { get; set; }
        public Dictionary<int, TFN> ProcessingTimes { get; set; } = new();  // MachineId -> TFN
        public List<int> EligibleMachines => ProcessingTimes.Keys.ToList();
        public int Flexibility => ProcessingTimes.Count;
        
        public double GetDuration(int machineId)
        {
            return ProcessingTimes.TryGetValue(machineId, out var tfn) ? tfn.GMIR : double.MaxValue;
        }
    }
    
    /// <summary>
    /// Machine with energy and PM parameters
    /// </summary>
    public class Machine
    {
        public int Id { get; set; }
        public double P_Proc { get; set; }      // Processing power (kW)
        public double P_Idle { get; set; }      // Idle power (kW)
        public double PM_Duration { get; set; } // PM duration
        public double PM_Early { get; set; }    // PM window start
        public double PM_Late { get; set; }     // PM window end
    }
    
    /// <summary>
    /// Cost Parameters (Thesis Table 3.6)
    /// Total Cost = C_time + C_energy + C_PM + C_startup
    /// </summary>
    public class CostParameters
    {
        public double C_Time { get; set; } = 100.0;       // $/hour - Time cost rate
        public double C_Energy { get; set; } = 0.08;      // $/kWh - Energy cost rate
        public double C_Startup { get; set; } = 200.0;    // $ per startup event
        public double C_Changeover_Min { get; set; } = 50.0;   // $ minimum changeover
        public double C_Changeover_Max { get; set; } = 500.0;  // $ maximum changeover
        public double C_PM_Direct { get; set; } = 400.0;  // $ direct PM cost per event
        public double C_PM_Delay { get; set; } = 20.0;    // $/hour - PM delay penalty
    }
    
    /// <summary>
    /// Problem instance
    /// </summary>
    public class Instance
    {
        public string Name { get; set; } = "";
        public int NumJobs { get; set; }
        public int NumMachines { get; set; }
        public double Delta { get; set; } = 0.2;
        public int BKS { get; set; }  // Best Known Solution (crisp makespan)
        public double AvgFlexibility { get; set; }
        public List<List<Operation>> Jobs { get; set; } = new();
        public List<Machine> Machines { get; set; } = new();
        public CostParameters Cost { get; set; } = new();  // Cost parameters from thesis
        
        public int TotalOps => Jobs.Sum(j => j.Count);
    }
    
    /// <summary>
    /// Scheduled operation with timing info
    /// </summary>
    public class ScheduledOp
    {
        public int Job { get; set; }
        public int Op { get; set; }
        public int Machine { get; set; }
        public double Start { get; set; }
        public double End { get; set; }
        public double Duration { get; set; }
    }
    
    /// <summary>
    /// Schedule with FJSP encoding: (Job, Op, Machine)
    /// Cost-based objective (Thesis Eq. 3.15)
    /// </summary>
    public class Schedule
    {
        public List<(int Job, int Op, int Machine)> Sequence { get; set; } = new();
        public List<ScheduledOp> DetailedSchedule { get; set; } = new();
        
        // Performance metrics
        public double Makespan { get; set; }      // Cmax (time units)
        public double Energy { get; set; }        // Total energy (kWh)
        
        // Cost breakdown (Thesis Table 3.6)
        public double TimeCost { get; set; }      // C_time × Cmax
        public double EnergyCost { get; set; }    // C_energy × E
        public double PMCost { get; set; }        // PM-related costs
        public double StartupCost { get; set; }   // Machine startup costs
        
        // Total objective (sum of all costs)
        public double Objective { get; set; }     // Total Cost ($)
        
        // PM schedule
        public double[] PMStartTimes { get; set; } = Array.Empty<double>();
        
        public Schedule Clone() => new()
        {
            Sequence = new List<(int, int, int)>(Sequence),
            DetailedSchedule = new List<ScheduledOp>(DetailedSchedule),
            Makespan = Makespan,
            Energy = Energy,
            TimeCost = TimeCost,
            EnergyCost = EnergyCost,
            PMCost = PMCost,
            StartupCost = StartupCost,
            Objective = Objective,
            PMStartTimes = (double[])PMStartTimes.Clone()
        };
    }
    
    public class AlgorithmResult
    {
        public string Name { get; set; } = "";
        public double Best { get; set; }
        public double Average { get; set; }
        public double Worst { get; set; }
        public double StdDev { get; set; }
        public double AvgTime { get; set; }
        public double RPD { get; set; }
        public int Rank { get; set; }
        public List<double> AllRuns { get; set; } = new();
        public List<List<double>> Convergences { get; set; } = new();
    }
    
    #endregion
    
    #region Instance Loader
    
    public static class InstanceLoader
    {
        /// <summary>
        /// Load GF-FJSP-PM instance from JSON file
        /// Supports BOTH old flat format and new nested format (with metadata section)
        /// </summary>
        public static Instance LoadFromJson(string path)
        {
            var json = File.ReadAllText(path);
            using var doc = JsonDocument.Parse(json);
            var root = doc.RootElement;
            
            var inst = new Instance();
            
            // Check if new nested format (has "metadata" section) or old flat format
            if (root.TryGetProperty("metadata", out var metadata))
            {
                // NEW FORMAT: nested with metadata section
                inst.Name = metadata.GetProperty("name").GetString() ?? "";
                inst.NumJobs = metadata.GetProperty("num_jobs").GetInt32();
                inst.NumMachines = metadata.GetProperty("num_machines").GetInt32();
                inst.Delta = metadata.TryGetProperty("fuzziness_delta", out var d) ? d.GetDouble() : 0.2;
                inst.BKS = metadata.TryGetProperty("bks_makespan", out var b) ? b.GetInt32() : 0;
                inst.AvgFlexibility = metadata.TryGetProperty("avg_flexibility", out var f) ? f.GetDouble() : 1.0;
            }
            else
            {
                // OLD FORMAT: flat structure
                inst.Name = root.GetProperty("name").GetString() ?? "";
                inst.NumJobs = root.GetProperty("num_jobs").GetInt32();
                inst.NumMachines = root.GetProperty("num_machines").GetInt32();
                inst.Delta = root.TryGetProperty("fuzziness_delta", out var d) ? d.GetDouble() : 0.2;
                inst.BKS = root.TryGetProperty("bks", out var b) ? b.GetInt32() : 
                          (root.TryGetProperty("bks_makespan", out var bm) ? bm.GetInt32() : 0);
                inst.AvgFlexibility = root.TryGetProperty("avg_flexibility", out var f) ? f.GetDouble() : 1.0;
            }
            
            // Load jobs and operations
            var jobsArray = root.GetProperty("jobs");
            foreach (var jobElem in jobsArray.EnumerateArray())
            {
                var jobOps = new List<Operation>();
                foreach (var opElem in jobElem.EnumerateArray())
                {
                    var op = new Operation
                    {
                        JobId = opElem.GetProperty("job_id").GetInt32(),
                        OpIdx = opElem.GetProperty("op_id").GetInt32()
                    };
                    
                    // Load processing times for each eligible machine
                    var ptElem = opElem.GetProperty("processing_times");
                    foreach (var pt in ptElem.EnumerateObject())
                    {
                        int machId = int.Parse(pt.Name);
                        var tfnElem = pt.Value;
                        op.ProcessingTimes[machId] = new TFN
                        {
                            L = tfnElem.GetProperty("L").GetDouble(),
                            M = tfnElem.GetProperty("M").GetDouble(),
                            U = tfnElem.GetProperty("U").GetDouble()
                        };
                    }
                    
                    jobOps.Add(op);
                }
                inst.Jobs.Add(jobOps);
            }
            
            // Load machines
            var machArray = root.GetProperty("machines");
            foreach (var machElem in machArray.EnumerateArray())
            {
                inst.Machines.Add(new Machine
                {
                    Id = machElem.GetProperty("id").GetInt32(),
                    P_Proc = machElem.GetProperty("P_proc_kW").GetDouble(),
                    P_Idle = machElem.GetProperty("P_idle_kW").GetDouble(),
                    PM_Duration = machElem.GetProperty("pm_duration").GetDouble(),
                    PM_Early = machElem.GetProperty("pm_window").EnumerateArray().First().GetDouble(),
                    PM_Late = machElem.GetProperty("pm_window").EnumerateArray().Last().GetDouble()
                });
            }
            
            // Load cost parameters (Thesis Table 3.6)
            if (root.TryGetProperty("parameters", out var parameters) &&
                parameters.TryGetProperty("cost", out var costElem))
            {
                inst.Cost = new CostParameters
                {
                    C_Time = costElem.TryGetProperty("c_time", out var ct) ? ct.GetDouble() : 100.0,
                    C_Energy = costElem.TryGetProperty("c_energy", out var ce) ? ce.GetDouble() : 0.08,
                    C_Startup = costElem.TryGetProperty("c_startup", out var cs) ? cs.GetDouble() : 200.0,
                    C_Changeover_Min = costElem.TryGetProperty("c_changeover_min", out var ccmin) ? ccmin.GetDouble() : 50.0,
                    C_Changeover_Max = costElem.TryGetProperty("c_changeover_max", out var ccmax) ? ccmax.GetDouble() : 500.0,
                    C_PM_Direct = costElem.TryGetProperty("c_pm_direct", out var cpmd) ? cpmd.GetDouble() : 400.0,
                    C_PM_Delay = costElem.TryGetProperty("c_pm_delay", out var cpmde) ? cpmde.GetDouble() : 20.0
                };
            }
            
            return inst;
        }
        
        /// <summary>
        /// Load all benchmark instances from a directory
        /// </summary>
        public static List<Instance> LoadBenchmarks(string dir = ".")
        {
            // Updated benchmark list - GF-LA instances only
            var benchmarks = new[] { 
                "GF-LA01", "GF-LA03", "GF-LA04", "GF-LA06", "GF-LA11"
            };
            var instances = new List<Instance>();
            
            foreach (var name in benchmarks)
            {
                var path = Path.Combine(dir, $"{name}.json");
                if (File.Exists(path))
                {
                    try
                    {
                        instances.Add(LoadFromJson(path));
                        Console.WriteLine($"  ✓ Loaded: {name}");
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"  ✗ Error loading {name}: {ex.Message}");
                    }
                }
                else
                {
                    Console.WriteLine($"  ⚠ Not found: {path}");
                }
            }
            
            return instances;
        }
    }
    
    #endregion
    
    #region Scheduler (FJSP) - Cost-Based Objective
    
    public class Scheduler
    {
        private readonly Instance _inst;
        
        public Scheduler(Instance inst)
        {
            _inst = inst;
        }
        
        /// <summary>
        /// Decode FJSP sequence to schedule with COST-BASED OBJECTIVE
        /// Thesis Eq. 3.15: Total Cost = C_time + C_energy + C_PM + C_startup
        /// 
        /// FIXED: PM scheduling and energy calculation
        /// </summary>
        public Schedule Decode(List<(int Job, int Op, int Machine)> seq)
        {
            var sch = new Schedule { Sequence = seq };
            var jobEnd = new double[_inst.NumJobs];
            var machEnd = new double[_inst.NumMachines];
            var machUsed = new bool[_inst.NumMachines];
            var machProcTime = new double[_inst.NumMachines];  // Total processing time per machine
            var machFirstStart = new double[_inst.NumMachines];
            var machLastEnd = new double[_inst.NumMachines];
            
            for (int i = 0; i < _inst.NumMachines; i++)
            {
                machFirstStart[i] = double.MaxValue;
                machLastEnd[i] = 0;
            }
            
            // Decode sequence and build detailed schedule
            foreach (var (j, o, m) in seq)
            {
                var op = _inst.Jobs[j][o];
                double duration = op.GetDuration(m);
                double start = Math.Max(jobEnd[j], machEnd[m]);
                double end = start + duration;
                
                jobEnd[j] = end;
                machEnd[m] = end;
                machUsed[m] = true;
                machProcTime[m] += duration;
                machFirstStart[m] = Math.Min(machFirstStart[m], start);
                machLastEnd[m] = Math.Max(machLastEnd[m], end);
                
                sch.DetailedSchedule.Add(new ScheduledOp
                {
                    Job = j,
                    Op = o,
                    Machine = m,
                    Start = start,
                    End = end,
                    Duration = duration
                });
            }
            
            sch.Makespan = machEnd.Max();
            
            // ================================================================
            // PM SCHEDULING (FIXED)
            // Schedule PM as early as possible within the window
            // PM must not overlap with operations on the same machine
            // ================================================================
            sch.PMStartTimes = new double[_inst.NumMachines];
            
            foreach (var m in _inst.Machines)
            {
                if (!machUsed[m.Id])
                {
                    // Machine not used, schedule PM at earliest possible time
                    sch.PMStartTimes[m.Id] = m.PM_Early;
                }
                else
                {
                    // Find gaps in machine schedule to fit PM
                    var machOps = sch.DetailedSchedule
                        .Where(op => op.Machine == m.Id)
                        .OrderBy(op => op.Start)
                        .ToList();
                    
                    double pmStart = m.PM_Early;
                    bool pmScheduled = false;
                    
                    // Try to schedule PM in a gap
                    double prevEnd = 0;
                    foreach (var op in machOps)
                    {
                        // Check if PM fits in gap [prevEnd, op.Start]
                        double gapStart = Math.Max(prevEnd, m.PM_Early);
                        double gapEnd = Math.Min(op.Start, m.PM_Late);
                        
                        if (gapEnd - gapStart >= m.PM_Duration && gapStart >= m.PM_Early)
                        {
                            pmStart = gapStart;
                            pmScheduled = true;
                            break;
                        }
                        prevEnd = op.End;
                    }
                    
                    // If no gap found, schedule after last operation
                    if (!pmScheduled)
                    {
                        pmStart = Math.Max(machLastEnd[m.Id], m.PM_Early);
                        pmStart = Math.Min(pmStart, m.PM_Late - m.PM_Duration);
                    }
                    
                    sch.PMStartTimes[m.Id] = Math.Max(pmStart, m.PM_Early);
                }
                
                // Update makespan to include PM completion
                double pmEnd = sch.PMStartTimes[m.Id] + m.PM_Duration;
                sch.Makespan = Math.Max(sch.Makespan, pmEnd);
            }
            
            // ================================================================
            // COST-BASED OBJECTIVE CALCULATION (Thesis Section 3.5)
            // ================================================================
            var cost = _inst.Cost;
            
            // 1. TIME COST: C_time × Cmax ($/hour × hours)
            sch.TimeCost = cost.C_Time * sch.Makespan;
            
            // 2. ENERGY COST: C_energy × E ($/kWh × kWh) - FIXED
            sch.Energy = 0;
            foreach (var m in _inst.Machines)
            {
                if (machUsed[m.Id])
                {
                    // Processing energy
                    sch.Energy += m.P_Proc * machProcTime[m.Id];
                    
                    // Idle energy: machine ON time minus processing time minus PM duration
                    // Machine is ON from first operation start to last operation end (or PM end)
                    double pmEnd = sch.PMStartTimes[m.Id] + m.PM_Duration;
                    double machActiveEnd = Math.Max(machLastEnd[m.Id], pmEnd);
                    double machActiveStart = Math.Min(machFirstStart[m.Id], sch.PMStartTimes[m.Id]);
                    double totalActiveTime = machActiveEnd - machActiveStart;
                    double idleTime = Math.Max(0, totalActiveTime - machProcTime[m.Id] - m.PM_Duration);
                    sch.Energy += m.P_Idle * idleTime;
                }
            }
            sch.EnergyCost = cost.C_Energy * sch.Energy;
            
            // 3. PM COST: Direct cost + delay penalty - FIXED
            sch.PMCost = 0;
            foreach (var m in _inst.Machines)
            {
                // Direct PM cost for each machine
                sch.PMCost += cost.C_PM_Direct;
                
                // PM delay penalty: how late PM is scheduled relative to PM_Early
                double delay = Math.Max(0, sch.PMStartTimes[m.Id] - m.PM_Early);
                sch.PMCost += cost.C_PM_Delay * delay;
            }
            
            // 4. STARTUP COST: One startup per used machine
            int numMachinesUsed = machUsed.Count(u => u);
            sch.StartupCost = cost.C_Startup * numMachinesUsed;
            
            // ================================================================
            // TOTAL COST OBJECTIVE (Thesis Eq. 3.15)
            // ================================================================
            sch.Objective = sch.TimeCost + sch.EnergyCost + sch.PMCost + sch.StartupCost;
            
            return sch;
        }
        
        /// <summary>
        /// Generate random FJSP sequence with random machine selection
        /// </summary>
        public List<(int, int, int)> RandomSeq(Random rng)
        {
            var seq = new List<(int, int, int)>();
            var nextOp = new int[_inst.NumJobs];
            
            while (seq.Count < _inst.TotalOps)
            {
                var eligible = Enumerable.Range(0, _inst.NumJobs)
                    .Where(j => nextOp[j] < _inst.Jobs[j].Count).ToList();
                if (eligible.Count == 0) break;
                
                int j = eligible[rng.Next(eligible.Count)];
                int o = nextOp[j];
                var op = _inst.Jobs[j][o];
                
                // Random machine selection from eligible machines
                int m = op.EligibleMachines[rng.Next(op.Flexibility)];
                
                seq.Add((j, o, m));
                nextOp[j]++;
            }
            return seq;
        }
        
        /// <summary>
        /// Select best machine for an operation based on earliest completion
        /// </summary>
        public int SelectBestMachine(int jobId, int opIdx, double[] machEnd, double[] jobEnd)
        {
            var op = _inst.Jobs[jobId][opIdx];
            int bestMach = op.EligibleMachines[0];
            double bestEnd = double.MaxValue;
            
            foreach (var m in op.EligibleMachines)
            {
                double start = Math.Max(jobEnd[jobId], machEnd[m]);
                double end = start + op.GetDuration(m);
                if (end < bestEnd)
                {
                    bestEnd = end;
                    bestMach = m;
                }
            }
            return bestMach;
        }
        
        /// <summary>
        /// Validate FJSP sequence
        /// </summary>
        public bool IsValid(List<(int, int, int)> seq)
        {
            var nextOp = new int[_inst.NumJobs];
            foreach (var (j, o, m) in seq)
            {
                if (o != nextOp[j]) return false;
                var op = _inst.Jobs[j][o];
                if (!op.EligibleMachines.Contains(m)) return false;
                nextOp[j]++;
            }
            return true;
        }
        
        /// <summary>
        /// Change machine for an operation (FJSP neighborhood)
        /// </summary>
        public List<(int, int, int)> ChangeMachine(List<(int, int, int)> seq, int idx, Random rng)
        {
            var n = new List<(int, int, int)>(seq);
            var (j, o, oldM) = n[idx];
            var op = _inst.Jobs[j][o];
            
            if (op.Flexibility <= 1) return n;  // No alternative machines
            
            var alternatives = op.EligibleMachines.Where(m => m != oldM).ToList();
            if (alternatives.Count == 0) return n;
            
            int newM = alternatives[rng.Next(alternatives.Count)];
            n[idx] = (j, o, newM);
            return n;
        }
        
        /// <summary>
        /// Print detailed schedule with start/end times - Gantt chart ready format
        /// </summary>
        public void PrintSchedule(Schedule sch, string title = "Schedule")
        {
            Console.WriteLine($"\n{"=",-80}");
            Console.WriteLine($"  {title}");
            Console.WriteLine($"{"=",-80}");
            
            // === MACHINE VIEW (for Machine Gantt Chart) ===
            Console.WriteLine($"\n  MACHINE VIEW (for Gantt Chart):");
            Console.WriteLine($"  {"-",-76}");
            for (int m = 0; m < _inst.NumMachines; m++)
            {
                var machOps = sch.DetailedSchedule.Where(g => g.Machine == m).OrderBy(g => g.Start).ToList();
                if (machOps.Count == 0) continue;
                
                Console.Write($"  M{m}: ");
                foreach (var op in machOps)
                {
                    Console.Write($"[J{op.Job}O{op.Op}|{op.Start:F1}-{op.End:F1}] ");
                }
                // Show PM
                Console.Write($"[PM|{sch.PMStartTimes[m]:F1}-{sch.PMStartTimes[m] + _inst.Machines[m].PM_Duration:F1}]");
                Console.WriteLine();
            }
            
            // === JOB VIEW (for Job Gantt Chart) ===
            Console.WriteLine($"\n  JOB VIEW (operation sequence per job):");
            Console.WriteLine($"  {"-",-76}");
            for (int j = 0; j < _inst.NumJobs; j++)
            {
                var jobOps = sch.DetailedSchedule.Where(g => g.Job == j).OrderBy(g => g.Op).ToList();
                Console.Write($"  J{j}: ");
                foreach (var op in jobOps)
                {
                    Console.Write($"[O{op.Op}→M{op.Machine}|{op.Start:F1}-{op.End:F1}] ");
                }
                Console.WriteLine();
            }
            
            // === CSV FORMAT (for external Gantt chart tools) ===
            Console.WriteLine($"\n  CSV FORMAT (Job,Op,Machine,Start,End,Duration):");
            Console.WriteLine($"  {"-",-76}");
            Console.WriteLine($"  Job,Op,Machine,Start,End,Duration");
            foreach (var g in sch.DetailedSchedule.OrderBy(x => x.Start))
            {
                Console.WriteLine($"  {g.Job},{g.Op},{g.Machine},{g.Start:F2},{g.End:F2},{g.Duration:F2}");
            }
            
            // === SUMMARY (Cost-Based Objective) ===
            Console.WriteLine($"\n  {"-",-76}");
            Console.WriteLine($"  SUMMARY (Cost-Based Objective - Thesis Eq. 3.15):");
            Console.WriteLine($"    Makespan (Cmax):   {sch.Makespan:F2} hours");
            Console.WriteLine($"    Total Energy:      {sch.Energy:F2} kWh");
            Console.WriteLine($"  {"-",-76}");
            Console.WriteLine($"  COST BREAKDOWN:");
            Console.WriteLine($"    Time Cost:         ${sch.TimeCost:F2}  (c_time × Cmax = {_inst.Cost.C_Time} × {sch.Makespan:F2})");
            Console.WriteLine($"    Energy Cost:       ${sch.EnergyCost:F2}  (c_energy × E = {_inst.Cost.C_Energy} × {sch.Energy:F2})");
            Console.WriteLine($"    PM Cost:           ${sch.PMCost:F2}  (direct + delay)");
            Console.WriteLine($"    Startup Cost:      ${sch.StartupCost:F2}  (c_startup × machines_used)");
            Console.WriteLine($"  {"-",-76}");
            Console.WriteLine($"    TOTAL COST:        ${sch.Objective:F2}");
            Console.WriteLine($"  {"-",-76}");
            Console.WriteLine($"    BKS (Cmax only):   {_inst.BKS}");
            Console.WriteLine($"    Gap to BKS:        {((_inst.BKS > 0) ? ((sch.Makespan - _inst.BKS) / _inst.BKS * 100) : 0):F2}%");
            Console.WriteLine($"{"=",-80}\n");
        }
        
        /// <summary>
        /// Check schedule feasibility (precedence + machine eligibility)
        /// </summary>
        public bool CheckFeasibility(Schedule sch, out string error)
        {
            error = "";
            var nextOp = new int[_inst.NumJobs];
            
            foreach (var (j, o, m) in sch.Sequence)
            {
                // Check operation precedence
                if (o != nextOp[j])
                {
                    error = $"Precedence violated: Job {j} Op {o} scheduled before Op {nextOp[j]}";
                    return false;
                }
                
                // Check machine eligibility
                var op = _inst.Jobs[j][o];
                if (!op.EligibleMachines.Contains(m))
                {
                    error = $"Machine eligibility violated: Job {j} Op {o} assigned to M{m}, eligible: [{string.Join(",", op.EligibleMachines)}]";
                    return false;
                }
                
                nextOp[j]++;
            }
            
            // Check all operations scheduled
            for (int j = 0; j < _inst.NumJobs; j++)
            {
                if (nextOp[j] != _inst.Jobs[j].Count)
                {
                    error = $"Missing operations: Job {j} has {_inst.Jobs[j].Count} ops, only {nextOp[j]} scheduled";
                    return false;
                }
            }
            
            return true;
        }
    }
    
    #endregion
    
    #region Base Algorithm
    
    public abstract class Algorithm
    {
        protected Instance Inst;
        protected Scheduler Sched;
        protected Random Rng;
        
        public Schedule? Best { get; protected set; }
        public double BestObj { get; protected set; } = double.MaxValue;
        public List<double> Convergence { get; } = new();
        public double Time { get; protected set; }
        public bool PrintDetails { get; set; } = false;
        
        protected Algorithm(Instance inst, Scheduler sched, int seed)
        {
            Inst = inst;
            Sched = sched;
            Rng = new Random(seed);
        }
        
        public abstract Schedule Solve(int maxIter);
        
        protected void TryUpdate(Schedule s)
        {
            if (s.Objective < BestObj) { BestObj = s.Objective; Best = s.Clone(); }
        }
        
        protected List<(int, int, int)> Swap(List<(int, int, int)> s, int i, int j)
        {
            var n = new List<(int, int, int)>(s);
            (n[i], n[j]) = (n[j], n[i]);
            return n;
        }
        
        protected List<(int, int, int)> Insert(List<(int, int, int)> s, int from, int to)
        {
            var n = new List<(int, int, int)>(s);
            var op = n[from]; n.RemoveAt(from); n.Insert(to, op);
            return n;
        }
    }
    
    #endregion
    
    #region ADP-ACO (Adaptive Dual-Pheromone ACO)
    
    /// <summary>
    /// Adaptive Dual-Pheromone ACO for FJSP (ADP-ACO)
    /// Thesis Chapter 4 - Proposed Algorithm
    /// 
    /// Features:
    /// 1. Dual pheromone: operation sequence (τ_op) + machine selection (τ_mach)
    /// 2. Attractive pheromone (τ⁺) + Repulsive pheromone (τ⁻)
    /// 3. Heuristic initialization (SPT, LPT)
    /// 4. Adaptive q₀ (exploration → exploitation)
    /// 5. Stagnation detection + restart mechanism
    /// 6. Multi-neighborhood local search (swap, insert, machine change)
    /// 
    /// Parameters (Thesis Table 4.1):
    /// ┌────────────────┬─────────┬──────────────────────────────────┐
    /// │ Parameter      │ Value   │ Reference                        │
    /// ├────────────────┼─────────┼──────────────────────────────────┤
    /// │ NumAnts        │ 30      │ Dorigo & Stützle (2004)          │
    /// │ MaxIter        │ 100     │ Computational budget             │
    /// │ α (pheromone)  │ 1.0     │ Dorigo & Gambardella (1997)      │
    /// │ β (heuristic)  │ 2.0     │ Dorigo & Gambardella (1997)      │
    /// │ γ (repulsive)  │ 0.5     │ Novel contribution               │
    /// │ ρ⁺ (evap τ⁺)   │ 0.1     │ Stützle & Hoos (2000)            │
    /// │ ρ⁻ (evap τ⁻)   │ 0.3     │ Novel contribution               │
    /// │ k⁺ (elite)     │ 1       │ Dorigo & Stützle (2004)          │
    /// │ k⁻ (worst)     │ 10      │ Novel contribution               │
    /// │ Stagnation     │ 15      │ Stützle & Hoos (2000)            │
    /// │ LS iterations  │ 30      │ Calibration                      │
    /// └────────────────┴─────────┴──────────────────────────────────┘
    /// </summary>
    public class ADPACO : Algorithm
    {
        // ACO Parameters (Thesis Table 4.1)
        private readonly int _ants;
        private readonly double _alpha = 1.0;     // Pheromone weight
        private readonly double _beta = 2.0;      // Heuristic weight
        private readonly double _gamma = 0.5;     // Repulsive pheromone weight
        private readonly double _rhoP = 0.1;      // Evaporation rate τ⁺
        private readonly double _rhoM = 0.3;      // Evaporation rate τ⁻
        private readonly int _kPlus = 1;          // Elite ants for τ⁺
        private readonly int _kMinus = 10;        // Worst ants for τ⁻
        private readonly int _maxStagnation = 15; // Restart threshold
        private readonly int _lsIterations = 30;  // Local search iterations
        
        // Operation pheromone: τ_op[prev+1, curr]
        private double[,] _tauOpP = null!;
        private double[,] _tauOpM = null!;
        // Machine pheromone: τ_mach[op_idx, machine]
        private double[,] _tauMachP = null!;
        private double[,] _tauMachM = null!;
        
        private Dictionary<(int, int), double> _eta = new();
        private Dictionary<(int, int), int> _opIdx = new();
        private int _n;
        
        private int _stagnationCount = 0;
        private double _lastBestObj = double.MaxValue;
        private int _currentIter = 0;
        private int _maxIter = 100;
        
        public ADPACO(Instance inst, Scheduler sched, int seed, int ants = 30) 
            : base(inst, sched, seed)
        {
            _ants = ants;
            Init();
        }
        
        private void Init()
        {
            _n = Inst.TotalOps;
            
            // Operation pheromone matrices
            _tauOpP = new double[_n + 1, _n];
            _tauOpM = new double[_n + 1, _n];
            
            // Machine pheromone matrices
            _tauMachP = new double[_n, Inst.NumMachines];
            _tauMachM = new double[_n, Inst.NumMachines];
            
            _eta = new(); _opIdx = new();
            
            // Initialize pheromones
            for (int i = 0; i <= _n; i++)
                for (int j = 0; j < _n; j++)
                { _tauOpP[i, j] = 1.0; _tauOpM[i, j] = 0.1; }
            
            for (int i = 0; i < _n; i++)
                for (int m = 0; m < Inst.NumMachines; m++)
                { _tauMachP[i, m] = 1.0; _tauMachM[i, m] = 0.1; }
            
            // Build operation index and heuristic
            int k = 0;
            for (int j = 0; j < Inst.NumJobs; j++)
                for (int o = 0; o < Inst.Jobs[j].Count; o++)
                {
                    _opIdx[(j, o)] = k;
                    // Heuristic: inverse of average processing time
                    var op = Inst.Jobs[j][o];
                    double avgDur = op.ProcessingTimes.Values.Average(t => t.GMIR);
                    _eta[(j, o)] = 1.0 / Math.Max(avgDur, 1);
                    k++;
                }
            
            // Initialize with heuristic solutions
            InitializeWithHeuristics();
        }
        
        private void InitializeWithHeuristics()
        {
            var goodSolutions = new List<Schedule>();
            
            for (int i = 0; i < 10; i++)
            {
                // SPT heuristic
                var sptSeq = ConstructHeuristic(true);
                goodSolutions.Add(Sched.Decode(sptSeq));
                
                // LPT heuristic
                var lptSeq = ConstructHeuristic(false);
                goodSolutions.Add(Sched.Decode(lptSeq));
                
                // Random + Local Search
                var randSeq = Sched.RandomSeq(Rng);
                var randSch = LocalSearchFull(Sched.Decode(randSeq));
                goodSolutions.Add(randSch);
            }
            
            goodSolutions = goodSolutions.OrderBy(s => s.Objective).ToList();
            
            var best = goodSolutions.First();
            if (best.Objective < BestObj)
            {
                BestObj = best.Objective;
                Best = best;
            }
            
            // Normalized deposit for cost-based objectives
            double refValue = Math.Max(BestObj, 1.0);
            double depositScale = 1000.0 / refValue;
            
            foreach (var sch in goodSolutions.Take(5))
            {
                double delta = 3.0 * depositScale / sch.Objective;
                DepositOp(_tauOpP, sch, delta);
                DepositMach(_tauMachP, sch, delta);
            }
        }
        
        private List<(int, int, int)> ConstructHeuristic(bool spt)
        {
            var seq = new List<(int, int, int)>();
            var next = new int[Inst.NumJobs];
            var machEnd = new double[Inst.NumMachines];
            var jobEnd = new double[Inst.NumJobs];
            
            while (seq.Count < _n)
            {
                var eligible = new List<(int j, int o, double dur, int m)>();
                for (int j = 0; j < Inst.NumJobs; j++)
                {
                    if (next[j] < Inst.Jobs[j].Count)
                    {
                        var op = Inst.Jobs[j][next[j]];
                        int bestM = Sched.SelectBestMachine(j, next[j], machEnd, jobEnd);
                        double dur = op.GetDuration(bestM);
                        eligible.Add((j, next[j], dur, bestM));
                    }
                }
                
                if (eligible.Count == 0) break;
                
                var chosen = spt 
                    ? eligible.OrderBy(e => e.dur + Rng.NextDouble() * 0.01).First()
                    : eligible.OrderByDescending(e => e.dur + Rng.NextDouble() * 0.01).First();
                
                seq.Add((chosen.j, chosen.o, chosen.m));
                
                double start = Math.Max(jobEnd[chosen.j], machEnd[chosen.m]);
                double end = start + chosen.dur;
                jobEnd[chosen.j] = end;
                machEnd[chosen.m] = end;
                
                next[chosen.j]++;
            }
            
            return seq;
        }
        
        public override Schedule Solve(int maxIter)
        {
            var sw = Stopwatch.StartNew();
            _maxIter = maxIter;
            _stagnationCount = 0;
            _lastBestObj = BestObj;
            
            for (int iter = 0; iter < maxIter; iter++)
            {
                _currentIter = iter;
                var sols = new List<Schedule>();
                
                for (int a = 0; a < _ants; a++)
                {
                    var seq = Construct();
                    var sch = Sched.Decode(seq);
                    
                    // Apply LS to promising ants
                    if (iter < maxIter * 0.2 || sch.Objective < BestObj * 1.1)
                        sch = LocalSearchFull(sch);
                    
                    sols.Add(sch);
                    TryUpdate(sch);
                }
                
                sols = sols.OrderBy(s => s.Objective).ToList();
                
                // Intensification on best
                if (iter % 5 == 0 && Best != null)
                {
                    var intensified = IntensifySearch(Best);
                    TryUpdate(intensified);
                }
                
                Update(sols);
                
                // Stagnation detection
                if (Math.Abs(BestObj - _lastBestObj) < 0.001)
                    _stagnationCount++;
                else
                {
                    _stagnationCount = 0;
                    _lastBestObj = BestObj;
                }
                
                if (_stagnationCount >= _maxStagnation)
                {
                    RestartPheromones();
                    _stagnationCount = 0;
                }
                
                Convergence.Add(BestObj);
            }
            
            // Final intensification
            if (Best != null)
                TryUpdate(IntensifySearch(Best));
            
            Time = sw.Elapsed.TotalSeconds;
            if (Best != null && PrintDetails) Sched.PrintSchedule(Best, $"{Inst.Name} ADP-ACO Best Schedule");
            return Best!;
        }
        
        private double GetQ0()
        {
            double progress = (double)_currentIter / _maxIter;
            return 0.5 + 0.45 * progress;
        }
        
        private List<(int, int, int)> Construct()
        {
            var seq = new List<(int, int, int)>();
            var next = new int[Inst.NumJobs];
            var machEnd = new double[Inst.NumMachines];
            var jobEnd = new double[Inst.NumJobs];
            int lastOpIdx = -1;
            double q0 = GetQ0();
            
            while (seq.Count < _n)
            {
                // Get eligible operations
                var el = new List<(int j, int o)>();
                for (int j = 0; j < Inst.NumJobs; j++)
                    if (next[j] < Inst.Jobs[j].Count)
                        el.Add((j, next[j]));
                if (el.Count == 0) break;
                
                // Select operation using pheromone
                var opProbs = new double[el.Count];
                double maxProb = 0;
                int maxIdx = 0;
                
                for (int i = 0; i < el.Count; i++)
                {
                    var (j, o) = el[i];
                    int id = _opIdx[(j, o)];
                    double tp = _tauOpP[lastOpIdx + 1, id];
                    double tm = Math.Max(_tauOpM[lastOpIdx + 1, id], 0.01);
                    opProbs[i] = Math.Pow(tp, _alpha) * Math.Pow(_eta[(j, o)], _beta) 
                              * Math.Pow(1.0 / tm, _gamma);
                    
                    if (opProbs[i] > maxProb) { maxProb = opProbs[i]; maxIdx = i; }
                }
                
                double sum = opProbs.Sum();
                if (sum > 0)
                    for (int i = 0; i < opProbs.Length; i++) opProbs[i] /= sum;
                else
                    for (int i = 0; i < opProbs.Length; i++) opProbs[i] = 1.0 / opProbs.Length;
                
                // Select operation
                (int, int) selOp;
                if (Rng.NextDouble() < q0)
                    selOp = el[maxIdx];
                else
                {
                    double r = Rng.NextDouble(), c = 0;
                    selOp = el[^1];
                    for (int i = 0; i < opProbs.Length; i++)
                    { c += opProbs[i]; if (r <= c) { selOp = el[i]; break; } }
                }
                
                int selJ = selOp.Item1, selO = selOp.Item2;
                int opId = _opIdx[(selJ, selO)];
                var op = Inst.Jobs[selJ][selO];
                
                // Select machine using pheromone
                int selM;
                if (op.Flexibility == 1)
                {
                    selM = op.EligibleMachines[0];
                }
                else
                {
                    var machProbs = new double[op.Flexibility];
                    double maxMachProb = 0;
                    int maxMachIdx = 0;
                    
                    for (int i = 0; i < op.Flexibility; i++)
                    {
                        int m = op.EligibleMachines[i];
                        double tp = _tauMachP[opId, m];
                        double tm = Math.Max(_tauMachM[opId, m], 0.01);
                        double etaM = 1.0 / op.GetDuration(m);
                        machProbs[i] = Math.Pow(tp, _alpha) * Math.Pow(etaM, _beta) 
                                     * Math.Pow(1.0 / tm, _gamma);
                        
                        if (machProbs[i] > maxMachProb) { maxMachProb = machProbs[i]; maxMachIdx = i; }
                    }
                    
                    double machSum = machProbs.Sum();
                    if (machSum > 0)
                        for (int i = 0; i < machProbs.Length; i++) machProbs[i] /= machSum;
                    else
                        for (int i = 0; i < machProbs.Length; i++) machProbs[i] = 1.0 / machProbs.Length;
                    
                    if (Rng.NextDouble() < q0)
                        selM = op.EligibleMachines[maxMachIdx];
                    else
                    {
                        double r = Rng.NextDouble(), c = 0;
                        selM = op.EligibleMachines[^1];
                        for (int i = 0; i < machProbs.Length; i++)
                        { c += machProbs[i]; if (r <= c) { selM = op.EligibleMachines[i]; break; } }
                    }
                }
                
                seq.Add((selJ, selO, selM));
                
                double start = Math.Max(jobEnd[selJ], machEnd[selM]);
                double end = start + op.GetDuration(selM);
                jobEnd[selJ] = end;
                machEnd[selM] = end;
                
                next[selJ]++;
                lastOpIdx = opId;
            }
            
            return seq;
        }
        
        private void Update(List<Schedule> sols)
        {
            // Evaporation
            for (int i = 0; i <= _n; i++)
                for (int j = 0; j < _n; j++)
                { _tauOpP[i, j] *= (1 - _rhoP); _tauOpM[i, j] *= (1 - _rhoM); }
            
            for (int i = 0; i < _n; i++)
                for (int m = 0; m < Inst.NumMachines; m++)
                { _tauMachP[i, m] *= (1 - _rhoP); _tauMachM[i, m] *= (1 - _rhoM); }
            
            // Normalize pheromone deposits for cost-based objectives
            double refValue = Math.Max(BestObj, 1.0);
            double depositScale = 1000.0 / refValue;
            
            // Deposit from best solutions
            foreach (var s in sols.Take(_kPlus))
            {
                double deposit = depositScale / s.Objective;
                DepositOp(_tauOpP, s, deposit);
                DepositMach(_tauMachP, s, deposit);
            }
            
            if (Best != null)
            {
                double deposit = 2.0 * depositScale / BestObj;
                DepositOp(_tauOpP, Best, deposit);
                DepositMach(_tauMachP, Best, deposit);
            }
            
            // Deposit repulsive pheromone from worst solutions
            foreach (var s in sols.TakeLast(_kMinus))
            {
                double d = (s.Objective - BestObj) / Math.Max(s.Objective, 1.0);
                d = Math.Max(d, 0.001) * depositScale;
                DepositOp(_tauOpM, s, d);
                DepositMach(_tauMachM, s, d);
            }
            
            // Fixed pheromone bounds (MMAS-style)
            double tMax = 10.0;
            double tMin = 0.01;
            for (int i = 0; i <= _n; i++)
                for (int j = 0; j < _n; j++)
                {
                    _tauOpP[i, j] = Math.Clamp(_tauOpP[i, j], tMin, tMax);
                    _tauOpM[i, j] = Math.Clamp(_tauOpM[i, j], tMin, tMax);
                }
            for (int i = 0; i < _n; i++)
                for (int m = 0; m < Inst.NumMachines; m++)
                {
                    _tauMachP[i, m] = Math.Clamp(_tauMachP[i, m], tMin, tMax);
                    _tauMachM[i, m] = Math.Clamp(_tauMachM[i, m], tMin, tMax);
                }
        }
        
        private void DepositOp(double[,] tau, Schedule s, double d)
        {
            int last = -1;
            foreach (var (j, o, _) in s.Sequence)
            { int id = _opIdx[(j, o)]; tau[last + 1, id] += d; last = id; }
        }
        
        private void DepositMach(double[,] tau, Schedule s, double d)
        {
            foreach (var (j, o, m) in s.Sequence)
            {
                int id = _opIdx[(j, o)];
                tau[id, m] += d;
            }
        }
        
        private void RestartPheromones()
        {
            for (int i = 0; i <= _n; i++)
                for (int j = 0; j < _n; j++)
                {
                    _tauOpP[i, j] = 0.5 * _tauOpP[i, j] + 0.5;
                    _tauOpM[i, j] = 0.5 * _tauOpM[i, j] + 0.05;
                }
            for (int i = 0; i < _n; i++)
                for (int m = 0; m < Inst.NumMachines; m++)
                {
                    _tauMachP[i, m] = 0.5 * _tauMachP[i, m] + 0.5;
                    _tauMachM[i, m] = 0.5 * _tauMachM[i, m] + 0.05;
                }
            
            double refValue = Math.Max(BestObj, 1.0);
            double depositScale = 1000.0 / refValue;
            
            if (Best != null)
            {
                DepositOp(_tauOpP, Best, 3.0 * depositScale / BestObj);
                DepositMach(_tauMachP, Best, 3.0 * depositScale / BestObj);
            }
            
            for (int i = 0; i < 3; i++)
            {
                var seq = ConstructHeuristic(i % 2 == 0);
                var sch = LocalSearchFull(Sched.Decode(seq));
                TryUpdate(sch);
                DepositOp(_tauOpP, sch, depositScale / sch.Objective);
                DepositMach(_tauMachP, sch, depositScale / sch.Objective);
            }
        }
        
        private Schedule LocalSearchFull(Schedule s)
        {
            var best = s;
            var seq = new List<(int, int, int)>(s.Sequence);
            
            for (int it = 0; it < _lsIterations; it++)
            {
                bool improved = false;
                
                // N1: Adjacent swap
                for (int i = 0; i < seq.Count - 1 && !improved; i++)
                {
                    var n = Swap(seq, i, i + 1);
                    if (Sched.IsValid(n))
                    {
                        var sch = Sched.Decode(n);
                        if (sch.Objective < best.Objective - 0.001)
                        { best = sch; seq = n; improved = true; }
                    }
                }
                
                // N2: General swap
                if (!improved)
                {
                    for (int i = 0; i < seq.Count && !improved; i++)
                    {
                        for (int j = i + 2; j < Math.Min(i + 15, seq.Count) && !improved; j++)
                        {
                            var n = Swap(seq, i, j);
                            if (Sched.IsValid(n))
                            {
                                var sch = Sched.Decode(n);
                                if (sch.Objective < best.Objective - 0.001)
                                { best = sch; seq = n; improved = true; }
                            }
                        }
                    }
                }
                
                // N3: Insert
                if (!improved)
                {
                    for (int i = 0; i < seq.Count && !improved; i++)
                    {
                        for (int j = 0; j < seq.Count && !improved; j++)
                        {
                            if (Math.Abs(i - j) <= 1) continue;
                            var n = Insert(seq, i, j);
                            if (Sched.IsValid(n))
                            {
                                var sch = Sched.Decode(n);
                                if (sch.Objective < best.Objective - 0.001)
                                { best = sch; seq = n; improved = true; }
                            }
                        }
                    }
                }
                
                // N4: Machine change (FJSP-specific)
                if (!improved)
                {
                    for (int i = 0; i < seq.Count && !improved; i++)
                    {
                        var n = Sched.ChangeMachine(seq, i, Rng);
                        var sch = Sched.Decode(n);
                        if (sch.Objective < best.Objective - 0.001)
                        { best = sch; seq = n; improved = true; }
                    }
                }
                
                if (!improved) break;
            }
            
            return best;
        }
        
        private Schedule IntensifySearch(Schedule s)
        {
            var best = s;
            var seq = new List<(int, int, int)>(s.Sequence);
            
            for (int restart = 0; restart < 3; restart++)
            {
                var currentSeq = new List<(int, int, int)>(seq);
                
                // Perturbation (swap + machine change)
                for (int p = 0; p < 3; p++)
                {
                    int i = Rng.Next(currentSeq.Count);
                    int j = Rng.Next(currentSeq.Count);
                    if (i != j)
                    {
                        var perturbed = Swap(currentSeq, i, j);
                        if (Sched.IsValid(perturbed))
                            currentSeq = perturbed;
                    }
                    
                    int k = Rng.Next(currentSeq.Count);
                    currentSeq = Sched.ChangeMachine(currentSeq, k, Rng);
                }
                
                // Deep local search
                for (int it = 0; it < 50; it++)
                {
                    bool improved = false;
                    
                    for (int i = 0; i < currentSeq.Count && !improved; i++)
                    {
                        for (int j = i + 1; j < currentSeq.Count && !improved; j++)
                        {
                            var n = Swap(currentSeq, i, j);
                            if (Sched.IsValid(n))
                            {
                                var sch = Sched.Decode(n);
                                if (sch.Objective < best.Objective - 0.001)
                                {
                                    best = sch;
                                    currentSeq = n;
                                    seq = n;
                                    improved = true;
                                }
                            }
                        }
                    }
                    
                    if (!improved)
                    {
                        for (int i = 0; i < currentSeq.Count && !improved; i++)
                        {
                            var n = Sched.ChangeMachine(currentSeq, i, Rng);
                            var sch = Sched.Decode(n);
                            if (sch.Objective < best.Objective - 0.001)
                            {
                                best = sch;
                                currentSeq = n;
                                seq = n;
                                improved = true;
                            }
                        }
                    }
                    
                    if (!improved) break;
                }
            }
            
            return best;
        }
    }
    
    #endregion
    
    #region HGATS - Hybrid GA with Tabu Search (Li & Gao, 2016)
    
    /// <summary>
    /// Hybrid Genetic Algorithm with Tabu Search (HGATS)
    /// Reference: Li & Gao (2016) - Computers & Industrial Engineering
    /// </summary>
    public class HGATS : Algorithm
    {
        private readonly int _pop = 100;
        private readonly double _cx = 0.8;
        private readonly double _mut = 0.1;
        private readonly int _tenure = 10;
        private readonly int _tabuIter = 15;
        
        public HGATS(Instance inst, Scheduler sched, int seed) : base(inst, sched, seed) { }
        
        public override Schedule Solve(int maxIter)
        {
            var sw = Stopwatch.StartNew();
            var pop = Enumerable.Range(0, _pop).Select(_ => Sched.RandomSeq(Rng)).ToList();
            
            for (int iter = 0; iter < maxIter; iter++)
            {
                var fit = pop.Select(s => {
                    var sch = Sched.Decode(s);
                    return (sch.Objective, s, sch);
                }).OrderBy(x => x.Objective).ToList();
                
                foreach (var (_, _, sch) in fit) TryUpdate(sch);
                
                for (int i = 0; i < _pop / 5; i++)
                {
                    var ts = TabuSearch(fit[i].s);
                    var tsSch = Sched.Decode(ts);
                    fit[i] = (tsSch.Objective, ts, tsSch);
                    TryUpdate(tsSch);
                }
                
                fit = fit.OrderBy(x => x.Objective).ToList();
                var np = new List<List<(int, int, int)>> { fit[0].s, fit[1].s };
                
                while (np.Count < _pop)
                {
                    var p1 = Tour(fit); var p2 = Tour(fit);
                    var (c1, c2) = Rng.NextDouble() < _cx ? POX(p1, p2) : (new List<(int,int,int)>(p1), new List<(int,int,int)>(p2));
                    np.Add(Mut(c1)); np.Add(Mut(c2));
                }
                
                pop = np.Take(_pop).ToList();
                Convergence.Add(BestObj);
            }
            
            Time = sw.Elapsed.TotalSeconds;
            return Best!;
        }
        
        private List<(int, int, int)> TabuSearch(List<(int, int, int)> init)
        {
            var cur = new List<(int, int, int)>(init);
            var curO = Sched.Decode(cur).Objective;
            var best = cur; var bestO = curO;
            var tabu = new HashSet<(int, int)>();
            var queue = new Queue<(int, int)>();
            
            for (int it = 0; it < _tabuIter; it++)
            {
                List<(int, int, int)>? bn = null; double bno = double.MaxValue; (int, int) bm = (-1, -1);
                
                for (int i = 0; i < cur.Count; i++)
                    for (int j = i + 1; j < Math.Min(i + 10, cur.Count); j++)
                    {
                        var m = (i, j);
                        if (tabu.Contains(m) && curO >= bestO) continue;
                        var n = Swap(cur, i, j);
                        if (!Sched.IsValid(n)) continue;
                        var no = Sched.Decode(n).Objective;
                        if (no < bno) { bn = n; bno = no; bm = m; }
                    }
                
                for (int i = 0; i < cur.Count; i++)
                {
                    var n = Sched.ChangeMachine(cur, i, Rng);
                    var no = Sched.Decode(n).Objective;
                    if (no < bno) { bn = n; bno = no; bm = (i, -1); }
                }
                
                if (bn != null)
                {
                    cur = bn; curO = bno;
                    if (curO < bestO) { best = cur; bestO = curO; }
                    if (bm.Item2 >= 0)
                    {
                        queue.Enqueue(bm); tabu.Add(bm);
                        if (queue.Count > _tenure) tabu.Remove(queue.Dequeue());
                    }
                }
            }
            return best;
        }
        
        private List<(int, int, int)> Tour(List<(double, List<(int, int, int)>, Schedule)> f, int k = 5)
            => Enumerable.Range(0, k).Select(_ => f[Rng.Next(f.Count)]).OrderBy(x => x.Item1).First().Item2;
        
        private (List<(int, int, int)>, List<(int, int, int)>) POX(List<(int, int, int)> p1, List<(int, int, int)> p2)
        {
            var js = Enumerable.Range(0, Inst.NumJobs).OrderBy(_ => Rng.Next()).ToList();
            var s = new HashSet<int>(js.Take(Inst.NumJobs / 2));
            return (POXChild(p1, p2, s), POXChild(p2, p1, s));
        }
        
        private List<(int, int, int)> POXChild(List<(int, int, int)> p1, List<(int, int, int)> p2, HashSet<int> s)
        {
            var c = new (int, int, int)?[p1.Count];
            for (int i = 0; i < p1.Count; i++) if (s.Contains(p1[i].Item1)) c[i] = p1[i];
            var r = p2.Where(x => !s.Contains(x.Item1)).ToList(); int ri = 0;
            for (int i = 0; i < c.Length; i++) if (c[i] == null) c[i] = r[ri++];
            return c.Select(x => x!.Value).ToList();
        }
        
        private List<(int, int, int)> Mut(List<(int, int, int)> s)
        {
            if (Rng.NextDouble() > _mut) return s;
            
            if (Rng.NextDouble() < 0.5)
            {
                var n = new List<(int, int, int)>(s);
                int i = Rng.Next(s.Count), j = Rng.Next(s.Count);
                (n[i], n[j]) = (n[j], n[i]);
                return Sched.IsValid(n) ? n : Sched.RandomSeq(Rng);
            }
            else
            {
                int idx = Rng.Next(s.Count);
                return Sched.ChangeMachine(s, idx, Rng);
            }
        }
    }
    
    #endregion
    
    #region HGAVND - Hybrid GA with VND (Gao et al., 2008)
    
    /// <summary>
    /// Hybrid Genetic Algorithm with Variable Neighborhood Descent (HGAVND)
    /// Reference: Gao et al. (2008) - Computers & Operations Research
    /// </summary>
    public class HGAVND : Algorithm
    {
        private readonly int _pop = 50;
        private readonly int _maxIterInternal = 300;
        private readonly double _cx = 0.7;
        private readonly double _mut = 0.1;
        private readonly double _vndProb = 0.4;
        
        public HGAVND(Instance inst, Scheduler sched, int seed) : base(inst, sched, seed) { }
        
        public override Schedule Solve(int maxIter)
        {
            var sw = Stopwatch.StartNew();
            var pop = Enumerable.Range(0, _pop).Select(_ => Sched.RandomSeq(Rng)).ToList();
            
            int actualIter = Math.Min(maxIter, _maxIterInternal);
            
            for (int iter = 0; iter < actualIter; iter++)
            {
                var fit = pop.Select(s => {
                    var sch = Sched.Decode(s);
                    return (sch.Objective, s, sch);
                }).OrderBy(x => x.Objective).ToList();
                
                foreach (var (_, _, sch) in fit) TryUpdate(sch);
                
                // Apply VND to top individuals
                for (int i = 0; i < _pop / 5; i++)
                {
                    if (Rng.NextDouble() < _vndProb)
                    {
                        var vndResult = VND(fit[i].s);
                        var vndSch = Sched.Decode(vndResult);
                        fit[i] = (vndSch.Objective, vndResult, vndSch);
                        TryUpdate(vndSch);
                    }
                }
                
                fit = fit.OrderBy(x => x.Objective).ToList();
                var np = new List<List<(int, int, int)>> { fit[0].s, fit[1].s };
                
                while (np.Count < _pop)
                {
                    var p1 = Tour(fit); var p2 = Tour(fit);
                    var (c1, c2) = Rng.NextDouble() < _cx ? POX(p1, p2) : (new List<(int,int,int)>(p1), new List<(int,int,int)>(p2));
                    np.Add(Mut(c1)); np.Add(Mut(c2));
                }
                
                pop = np.Take(_pop).ToList();
                Convergence.Add(BestObj);
            }
            
            // Pad convergence for consistency
            while (Convergence.Count < maxIter)
                Convergence.Add(BestObj);
            
            Time = sw.Elapsed.TotalSeconds;
            return Best!;
        }
        
        private List<(int, int, int)> VND(List<(int, int, int)> seq)
        {
            var cur = new List<(int, int, int)>(seq);
            var curO = Sched.Decode(cur).Objective;
            int k = 1;
            
            while (k <= 4)
            {
                bool imp = false;
                
                if (k == 1) // Adjacent swap
                {
                    for (int i = 0; i < cur.Count - 1 && !imp; i++)
                    {
                        var n = Swap(cur, i, i + 1);
                        if (Sched.IsValid(n))
                        {
                            var nSch = Sched.Decode(n);
                            if (nSch.Objective < curO)
                            { cur = n; curO = nSch.Objective; imp = true; }
                        }
                    }
                }
                else if (k == 2) // General swap
                {
                    for (int i = 0; i < cur.Count && !imp; i++)
                    {
                        for (int j = i + 2; j < cur.Count && !imp; j++)
                        {
                            var n = Swap(cur, i, j);
                            if (Sched.IsValid(n))
                            {
                                var nSch = Sched.Decode(n);
                                if (nSch.Objective < curO)
                                { cur = n; curO = nSch.Objective; imp = true; }
                            }
                        }
                    }
                }
                else if (k == 3) // Insert
                {
                    for (int i = 0; i < cur.Count && !imp; i++)
                    {
                        for (int j = 0; j < cur.Count && !imp; j++)
                        {
                            if (Math.Abs(i - j) <= 1) continue;
                            var n = Insert(cur, i, j);
                            if (Sched.IsValid(n))
                            {
                                var nSch = Sched.Decode(n);
                                if (nSch.Objective < curO)
                                { cur = n; curO = nSch.Objective; imp = true; }
                            }
                        }
                    }
                }
                else // Machine change (FJSP)
                {
                    for (int i = 0; i < cur.Count && !imp; i++)
                    {
                        var n = Sched.ChangeMachine(cur, i, Rng);
                        var nSch = Sched.Decode(n);
                        if (nSch.Objective < curO)
                        { cur = n; curO = nSch.Objective; imp = true; }
                    }
                }
                
                k = imp ? 1 : k + 1;
            }
            return cur;
        }
        
        private List<(int, int, int)> Tour(List<(double, List<(int, int, int)>, Schedule)> f, int k = 3)
            => Enumerable.Range(0, k).Select(_ => f[Rng.Next(f.Count)]).OrderBy(x => x.Item1).First().Item2;
        
        private (List<(int, int, int)>, List<(int, int, int)>) POX(List<(int, int, int)> p1, List<(int, int, int)> p2)
        {
            var js = Enumerable.Range(0, Inst.NumJobs).OrderBy(_ => Rng.Next()).ToList();
            var s = new HashSet<int>(js.Take(Inst.NumJobs / 2));
            return (POXChild(p1, p2, s), POXChild(p2, p1, s));
        }
        
        private List<(int, int, int)> POXChild(List<(int, int, int)> p1, List<(int, int, int)> p2, HashSet<int> s)
        {
            var c = new (int, int, int)?[p1.Count];
            for (int i = 0; i < p1.Count; i++) if (s.Contains(p1[i].Item1)) c[i] = p1[i];
            var r = p2.Where(x => !s.Contains(x.Item1)).ToList(); int ri = 0;
            for (int i = 0; i < c.Length; i++) if (c[i] == null) c[i] = r[ri++];
            return c.Select(x => x!.Value).ToList();
        }
        
        private List<(int, int, int)> Mut(List<(int, int, int)> s)
        {
            if (Rng.NextDouble() > _mut) return s;
            
            if (Rng.NextDouble() < 0.5)
            {
                var n = new List<(int, int, int)>(s);
                int i = Rng.Next(s.Count), j = Rng.Next(s.Count);
                (n[i], n[j]) = (n[j], n[i]);
                return Sched.IsValid(n) ? n : Sched.RandomSeq(Rng);
            }
            else
            {
                int idx = Rng.Next(s.Count);
                return Sched.ChangeMachine(s, idx, Rng);
            }
        }
    }
    
    #endregion
    
    #region Statistics
    
    public static class Stats
    {
        public static double StdDev(List<double> values)
        {
            if (values.Count < 2) return 0;
            double avg = values.Average();
            return Math.Sqrt(values.Sum(v => (v - avg) * (v - avg)) / (values.Count - 1));
        }
        
        public static (double W, double P, bool Significant) Wilcoxon(double[] x, double[] y, double alpha = 0.05)
        {
            int n = x.Length;
            var diffs = new List<(double abs, int sign, int origIdx)>();
            
            for (int i = 0; i < n; i++)
            {
                double d = x[i] - y[i];
                if (Math.Abs(d) > 1e-10)
                    diffs.Add((Math.Abs(d), Math.Sign(d), i));
            }
            
            if (diffs.Count < 3) return (0, 1.0, false);
            
            var ranked = diffs.OrderBy(d => d.abs).ToList();
            for (int i = 0; i < ranked.Count; i++)
                ranked[i] = (i + 1, ranked[i].sign, ranked[i].origIdx);
            
            double Wp = ranked.Where(r => r.sign > 0).Sum(r => r.abs);
            double Wm = ranked.Where(r => r.sign < 0).Sum(r => r.abs);
            double W = Math.Min(Wp, Wm);
            
            int nn = ranked.Count;
            double mean = nn * (nn + 1) / 4.0;
            double std = Math.Sqrt(nn * (nn + 1) * (2 * nn + 1) / 24.0);
            double z = std > 0 ? (W - mean) / std : 0;
            double p = 2 * (1 - NormalCDF(Math.Abs(z)));
            
            return (W, p, p < alpha);
        }
        
        public static (double Chi, double P, double[] AvgRanks) Friedman(double[,] data)
        {
            int n = data.GetLength(0);
            int k = data.GetLength(1);
            var ranks = new double[n, k];
            
            for (int i = 0; i < n; i++)
            {
                var row = Enumerable.Range(0, k).Select(j => (val: data[i, j], idx: j)).OrderBy(x => x.val).ToList();
                for (int r = 0; r < k; r++)
                    ranks[i, row[r].idx] = r + 1;
            }
            
            var avgRanks = new double[k];
            for (int j = 0; j < k; j++)
            {
                double sum = 0;
                for (int i = 0; i < n; i++) sum += ranks[i, j];
                avgRanks[j] = sum / n;
            }
            
            double chi = 12.0 * n / (k * (k + 1)) * avgRanks.Sum(r => (r - (k + 1) / 2.0) * (r - (k + 1) / 2.0));
            double p = 1 - ChiSquareCDF(chi, k - 1);
            
            return (chi, p, avgRanks);
        }
        
        private static double NormalCDF(double z)
        {
            double a1 = 0.254829592, a2 = -0.284496736, a3 = 1.421413741;
            double a4 = -1.453152027, a5 = 1.061405429, p = 0.3275911;
            int sign = z < 0 ? -1 : 1;
            z = Math.Abs(z) / Math.Sqrt(2);
            double t = 1.0 / (1.0 + p * z);
            double y = 1.0 - (((((a5 * t + a4) * t) + a3) * t + a2) * t + a1) * t * Math.Exp(-z * z);
            return 0.5 * (1.0 + sign * y);
        }
        
        private static double ChiSquareCDF(double x, int df)
        {
            if (x <= 0) return 0;
            return LowerIncompleteGamma(df / 2.0, x / 2.0) / Gamma(df / 2.0);
        }
        
        private static double Gamma(double z)
        {
            double[] g = { 76.18009172947146, -86.50532032941677, 24.01409824083091,
                          -1.231739572450155, 0.1208650973866179e-2, -0.5395239384953e-5 };
            double x = z, y = z;
            double tmp = x + 5.5;
            tmp -= (x + 0.5) * Math.Log(tmp);
            double ser = 1.000000000190015;
            for (int j = 0; j < 6; j++) ser += g[j] / ++y;
            return Math.Exp(-tmp + Math.Log(2.5066282746310005 * ser / x));
        }
        
        private static double LowerIncompleteGamma(double a, double x)
        {
            double sum = 0, term = 1.0 / a;
            for (int n = 1; n < 100; n++)
            {
                sum += term;
                term *= x / (a + n);
            }
            return Math.Pow(x, a) * Math.Exp(-x) * sum;
        }
    }
    
    #endregion
    
    #region Experiment Runner
    
    public static class Experiment
    {
        public static int NumRuns { get; set; } = 10;
        public static int MaxIter { get; set; } = 100;
        
        public static void Run(string instanceDir = ".")
        {
            Console.WriteLine("=".PadRight(100, '='));
            Console.WriteLine("GF-FJSP-PM ALGORITHM COMPARISON");
            Console.WriteLine("Cost-Based Objective (Thesis Eq. 3.15)");
            Console.WriteLine("=".PadRight(100, '='));
            
            Console.WriteLine("\nLoading instances...");
            var instances = InstanceLoader.LoadBenchmarks(instanceDir);
            
            if (instances.Count == 0)
            {
                Console.WriteLine("No instances found! Place GF-LA*.json files in current directory.");
                return;
            }
            
            Console.WriteLine($"\nExperiment: {NumRuns} runs × {MaxIter} iterations");
            Console.WriteLine($"Objective: Total Cost = C_time + C_energy + C_PM + C_startup");
            
            var allResults = new Dictionary<string, List<AlgorithmResult>>();
            
            foreach (var inst in instances)
            {
                var sched = new Scheduler(inst);
                
                Console.WriteLine($"\n{new string('-', 100)}");
                Console.WriteLine($"Instance: {inst.Name} ({inst.NumJobs}×{inst.NumMachines}, {inst.TotalOps} ops, BKS={inst.BKS})");
                Console.WriteLine($"{new string('-', 100)}");
                Console.WriteLine($"{"Algorithm",-12} {"Best($)",-12} {"Avg($)",-12} {"Std",-10} {"Time(s)",-10} {"RPD(%)",-10} {"Rank",-6}");
                Console.WriteLine(new string('-', 100));
                
                var algos = new (string Name, Func<int, Algorithm> Create)[]
                {
                    ("ADP-ACO", seed => new ADPACO(inst, sched, seed, ants: 30)),
                    ("HGATS", seed => new HGATS(inst, sched, seed)),
                    ("HGAVND", seed => new HGAVND(inst, sched, seed))
                };
                
                var results = new List<AlgorithmResult>();
                Schedule? bestScheduleOverall = null;
                string bestAlgoName = "";
                double bestObjOverall = double.MaxValue;
                
                foreach (var (name, create) in algos)
                {
                    var runs = new List<double>();
                    var times = new List<double>();
                    var convs = new List<List<double>>();
                    
                    for (int r = 0; r < NumRuns; r++)
                    {
                        var algo = create(42 + r);
                        var sch = algo.Solve(MaxIter);
                        runs.Add(sch.Objective);
                        times.Add(algo.Time);
                        convs.Add(algo.Convergence);
                        
                        if (sch.Objective < bestObjOverall)
                        {
                            bestObjOverall = sch.Objective;
                            bestScheduleOverall = sch.Clone();
                            bestAlgoName = name;
                        }
                    }
                    
                    results.Add(new AlgorithmResult
                    {
                        Name = name,
                        Best = runs.Min(),
                        Average = runs.Average(),
                        Worst = runs.Max(),
                        StdDev = Stats.StdDev(runs),
                        AvgTime = times.Average(),
                        AllRuns = runs,
                        Convergences = convs
                    });
                }
                
                double bestOfAll = results.Min(r => r.Best);
                foreach (var r in results)
                    r.RPD = (r.Best - bestOfAll) / bestOfAll * 100;
                
                var ranked = results.OrderBy(r => r.Best).ToList();
                for (int i = 0; i < ranked.Count; i++)
                    ranked[i].Rank = i + 1;
                
                foreach (var r in results)
                {
                    Console.WriteLine($"{r.Name,-12} {r.Best,-12:F2} {r.Average,-12:F2} {r.StdDev,-10:F2} {r.AvgTime,-10:F2} {r.RPD,-10:F2} {r.Rank,-6}");
                }
                
                if (bestScheduleOverall != null)
                {
                    if (sched.CheckFeasibility(bestScheduleOverall, out string error))
                    {
                        Console.WriteLine($"\n  ✓ Schedule is FEASIBLE");
                        sched.PrintSchedule(bestScheduleOverall, $"{inst.Name} BEST SOLUTION (by {bestAlgoName})");
                    }
                    else
                    {
                        Console.WriteLine($"\n  ✗ Schedule is INFEASIBLE: {error}");
                    }
                }
                
                allResults[inst.Name] = results;
            }
            
            // Statistical Tests
            Console.WriteLine($"\n{new string('=', 100)}");
            Console.WriteLine("STATISTICAL ANALYSIS");
            Console.WriteLine(new string('=', 100));
            
            Console.WriteLine("\nWilcoxon Signed-Rank Test (α=0.05): ADP-ACO vs Others");
            foreach (var (instName, results) in allResults)
            {
                Console.WriteLine($"\n  {instName}:");
                var adp = results.First(r => r.Name == "ADP-ACO").AllRuns.ToArray();
                foreach (var r in results.Where(r => r.Name != "ADP-ACO"))
                {
                    var other = r.AllRuns.ToArray();
                    if (adp.Length == other.Length && adp.Length >= 3)
                    {
                        var (w, p, sig) = Stats.Wilcoxon(adp, other);
                        Console.WriteLine($"    vs {r.Name,-10}: W={w:F1}, p={p:F4}, {(sig ? "SIGNIFICANT" : "not significant")}");
                    }
                }
            }
            
            Console.WriteLine("\nFriedman Test (Overall Ranking):");
            var algoNames = new[] { "ADP-ACO", "HGATS", "HGAVND" };
            int nInst = allResults.Count;
            var matrix = new double[nInst, algoNames.Length];
            
            int idx = 0;
            foreach (var (_, results) in allResults)
            {
                for (int j = 0; j < algoNames.Length; j++)
                {
                    var r = results.FirstOrDefault(x => x.Name == algoNames[j]);
                    matrix[idx, j] = r?.Best ?? double.MaxValue;
                }
                idx++;
            }
            
            var (chi, pVal, avgRanks) = Stats.Friedman(matrix);
            Console.WriteLine($"  Chi-square = {chi:F2}, p-value = {pVal:F4}");
            Console.WriteLine($"  {(pVal < 0.05 ? "SIGNIFICANT difference exists" : "No significant difference")}");
            Console.WriteLine("\n  Average Ranks:");
            for (int j = 0; j < algoNames.Length; j++)
                Console.WriteLine($"    {algoNames[j],-12}: {avgRanks[j]:F2}");
            
            SaveResults(allResults);
            SaveConvergenceData(allResults);
            
            Console.WriteLine($"\n{new string('=', 100)}");
            Console.WriteLine("Output files:");
            Console.WriteLine("  - comparison_results.json: Full comparison data");
            Console.WriteLine("  - convergence_data.json: For plotting convergence curves");
            Console.WriteLine(new string('=', 100));
        }
        
        static void SaveResults(Dictionary<string, List<AlgorithmResult>> results)
        {
            var data = new Dictionary<string, object>();
            
            foreach (var (inst, algResults) in results)
            {
                data[inst] = algResults.Select(r => new
                {
                    algorithm = r.Name,
                    best = Math.Round(r.Best, 2),
                    average = Math.Round(r.Average, 2),
                    worst = Math.Round(r.Worst, 2),
                    std_dev = Math.Round(r.StdDev, 2),
                    avg_time = Math.Round(r.AvgTime, 2),
                    rpd = Math.Round(r.RPD, 2),
                    rank = r.Rank,
                    all_runs = r.AllRuns.Select(x => Math.Round(x, 2))
                });
            }
            
            var opts = new JsonSerializerOptions { WriteIndented = true };
            File.WriteAllText("comparison_results.json", JsonSerializer.Serialize(data, opts));
        }
        
        static void SaveConvergenceData(Dictionary<string, List<AlgorithmResult>> results)
        {
            var data = new Dictionary<string, object>();
            
            foreach (var (inst, algResults) in results)
            {
                data[inst] = algResults.ToDictionary(
                    r => r.Name,
                    r => r.Convergences.FirstOrDefault()?.Select(x => Math.Round(x, 2)) ?? Enumerable.Empty<double>()
                );
            }
            
            var opts = new JsonSerializerOptions { WriteIndented = true };
            File.WriteAllText("convergence_data.json", JsonSerializer.Serialize(data, opts));
        }
    }
    
    #endregion
    
    #region Main Entry Point
    
    class Program
    {
        static void Main(string[] args)
        {
            string instanceDir = ".";
            
            // Parse command line arguments
            for (int i = 0; i < args.Length; i++)
            {
                if (args[i] == "-d" || args[i] == "--dir")
                {
                    if (i + 1 < args.Length)
                        instanceDir = args[++i];
                }
                else if (args[i] == "-r" || args[i] == "--runs")
                {
                    if (i + 1 < args.Length && int.TryParse(args[++i], out int runs))
                        Experiment.NumRuns = runs;
                }
                else if (args[i] == "-i" || args[i] == "--iter")
                {
                    if (i + 1 < args.Length && int.TryParse(args[++i], out int iter))
                        Experiment.MaxIter = iter;
                }
                else if (args[i] == "-h" || args[i] == "--help")
                {
                    PrintHelp();
                    return;
                }
            }
            
            Experiment.Run(instanceDir);
        }
        
        static void PrintHelp()
        {
            Console.WriteLine(@"
GF-FJSP-PM Metaheuristics Comparison

Usage: dotnet run [options]

Options:
  -d, --dir <path>    Directory containing GF-LA*.json instances (default: .)
  -r, --runs <n>      Number of independent runs (default: 10)
  -i, --iter <n>      Maximum iterations per run (default: 100)
  -h, --help          Show this help message

Examples:
  dotnet run -d ./instances -r 10 -i 100
  dotnet run --dir C:\data\benchmarks --runs 30 --iter 500

Algorithms:
  - ADP-ACO:  Adaptive Dual-Pheromone ACO (Proposed)
  - HGATS:    Hybrid GA with Tabu Search
  - HGAVND:   Hybrid GA with VND

Output:
  - comparison_results.json  : Detailed results for all algorithms
  - convergence_data.json    : Convergence curves for plotting
");
        }
    }
    
    #endregion
}
